<!DOCTYPE html>
<html class="no-js" lang="en"><head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><meta lang="" name="keywords" content="Bbq food truck,Milton,The Mills BBQ" /><meta lang="" name="description" content="Check out our specials."  /><meta name="robots" content="index, follow" /><title>Specials – Milton | The Mills BBQ</title><!--[if lt IE 9]>
<script src="/AMBIANCE_FBNWQMW54V_bambooBay-grid/js/vendor/html5shiv.min.js"></script>
<![endif]-->
<link href="/css/ambiance.min.css?v=1632458181" rel="stylesheet" type="text/css" /><link href="/css/styles.PAGE_EI9BTFC1R8.min.css?v=1632458287" rel="stylesheet" type="text/css" /></head><body itemscope itemtype="http://schema.org/Organization" class="content gridAmbiance" id="PAGE_EI9BTFC1R8">
<div class="stickyfooter">
<!-- ==================================
Tab mobile spacer
=================================== -->
<div id="tab-mobile-spacer"></div>
<!-- ==================================
Header
=================================== -->
<input id="publicPath" value="" hidden /><header class="dzone-header">
<div class="grid-template">
<figure class="block-logo">
<a href="/">
<span class="logo"><img itemprop="logo" alt="The Mills BBQ" src="ressources/images/d161b2f85b7f.png" /></span>
</a>
</figure>
<div class="block-slogan">
<p class="slogan">
An extravagant barbecue experience
</p>
</div>
<div class="block-call-to-action">
<div class="block-button button-style2">
<a href="https://deliver.biz/carte/carte?key=a9d7853e58c8738e31047dac36dd0699db839448&c=AGCCND6317&ui=light&lang=en&noiframe=true" target="_blank" class="button">
<span class="ico"><svg width="16" height="16" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" class="icon-Misc06"><path class="color1" d="M69.8 233.5H413c5.3 0 9.5-4.3 9.5-9.5 0-97-76.6-176.4-172.5-180.9 6-3.1 10-9.4 10-16.5 0-10.3-8.4-18.7-18.7-18.7 -10.3 0-18.7 8.4-18.7 18.7 0 7.2 4.1 13.4 10 16.5C136.9 47.5 60.3 127 60.3 224 60.3 229.2 64.6 233.5 69.8 233.5zM241.4 61.9c86.2 0 156.8 67.6 161.8 152.5H79.6C84.6 129.5 155.3 61.9 241.4 61.9zM193.1 92.6c-20.9 14.4-38.3 33.8-50.3 56.1 -2.5 4.6-0.8 10.4 3.9 12.9 1.4 0.8 3 1.1 4.5 1.1 3.4 0 6.7-1.8 8.4-5 10.6-19.7 25.9-36.8 44.3-49.4 4.3-3 5.4-8.9 2.5-13.3C203.4 90.7 197.5 89.6 193.1 92.6zM341.2 431.2l-122.8-71 -80.7-89.6H164l62.4 49.9c7.8 6.2 17.2 9.8 27.2 10.4 43.3 2.4 52.6-8.3 55.7-11.9 10-11.6 17.8-36 21.3-48.5H348c-6.1 23.5-15 73.7 9.8 103.3 3.4 4 9.4 4.6 13.5 1.2 4-3.4 4.6-9.4 1.2-13.5 -20.8-24.8-9.6-73.5-4.6-91h62.4c5.3 0 9.5-4.3 9.5-9.5s-4.3-9.5-9.5-9.5h-69.4 -37.4 -156 -51.2H52.7c-5.3 0-9.5 4.3-9.5 9.5s4.3 9.5 9.5 9.5h59.2l93.2 103.5c0.7 0.7 1.5 1.4 2.3 1.9l124.1 71.7c1.5 0.9 3.1 1.3 4.8 1.3 3.3 0 6.5-1.7 8.3-4.8C347.3 439.7 345.7 433.8 341.2 431.2zM294.8 306.6c-2.3 2.7-13.4 6.8-40.2 5.3 -6-0.3-11.6-2.5-16.3-6.3l-43.8-35h116.2C306.9 283 301 299.5 294.8 306.6zM462.3 379.9l-54.9-18.1c-4.7-1.5-9.8 0.7-11.7 5.2l-46.2 105.7c-1.1 2.5-1.1 5.3 0 7.7 1.1 2.5 3.2 4.3 5.7 5.2l54.9 18.1c1 0.3 2 0.5 3 0.5 4 0 7.7-2.5 9.1-6.6 1.7-5-1.1-10.4-6.1-12.1l-44.9-14.8 38.6-88.1 46.6 15.4c5 1.7 10.4-1.1 12.1-6.1C470 386.9 467.3 381.5 462.3 379.9z" /></svg></span>
<span class="txt"><span>Order Now</span></span>
</a>
</div>
</div>
</div>
</header>
<div class="HeaderFloatingButton">
<div class="block-button">
<a href="https://www.ubereats.com/ca/toronto/food-delivery/the-mills/ynJr-olTSxy6oYNmxKrHAA?pl=JTdCJTIyYWRkcmVzcyUyMiUzQSUyMlRoZSUyME1pbGxzJTIwYXQlMjBKZXJzZXklMjBHYXJkZW5zJTIyJTJDJTIycmVmZXJlbmNlJTIyJTNBJTIyQ2hJSml4UWVOSUJOd29rUkl0WFVWOHVqTGpRJTIyJTJDJTIycmVmZXJlbmNlVHlwZSUyMiUzQSUyMmdvb2dsZV9wbGFjZXMlMjIlMkMlMjJsYXRpdHVkZSUyMiUzQTQwLjY2MTI1ODMlMkMlMjJsb25naXR1ZGUlMjIlM0EtNzQuMTcxNDg1JTdE" target="_blank">
<img itemprop="logo" alt="The Mills BBQ" src="ressources/images/01caa85cbad6.png" />
</a>
</div>
<div class="block-button button-style2">
<a href="https://www.doordash.com/store/the-mills-milton-1167628" target="_blank">
<img itemprop="logo" alt="The Mills BBQ" src="ressources/images/4c5b188b4db1.png" />
</a>
</div>
<div class="block-button button-style2">
<a href="https://foodling.co/stores/the-mills-bbq" target="_blank">
<img itemprop="logo" alt="Foodling" src="ressources/images/39100cc533f8.png" />
</a>
</div>
</div><!-- ==================================
Top Nav
=================================== --><nav class="dzone-topnav top-bar top-nav block-nav sticky-position" data-topbar="" data-options="custom_back_text: false">
<div class="grid-template">
<figure class="block-logo">
<a href="/">
<span class="logo"><img itemprop="logo" alt="The Mills BBQ" src="ressources/images/740341b4ebff.png" /></span>
<span class="name" itemprop="name">The Mills BBQ</span>
</a>
</figure>
<div class="top-bar-section">
<ul>
              <li><a href="/" target="_self">Home</a></li>
              <li><a href="/specials.php" target="_self">Specials</a></li>
              <li><a href="/menu.php" target="_self">Menu</a></li>
              <li><a href="https://deliver.biz/carte/carte?key=a9d7853e58c8738e31047dac36dd0699db839448&amp;c=AGCCND6317&amp;ui=light&amp;lang=en&amp;noiframe=true" target="_blank">Order Now</a></li>
              <li><a href="/contact.php" target="_self">Contact Us</a></li>
</ul>
</div>
<div class="block-button">
<a href="https://deliver.biz/carte/carte?key=a9d7853e58c8738e31047dac36dd0699db839448&c=AGCCND6317&ui=light&lang=en&noiframe=true" target="_blank" class="button">
<span class="ico"><svg width="16" height="16" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" class="icon-Misc06"><path class="color1" d="M69.8 233.5H413c5.3 0 9.5-4.3 9.5-9.5 0-97-76.6-176.4-172.5-180.9 6-3.1 10-9.4 10-16.5 0-10.3-8.4-18.7-18.7-18.7 -10.3 0-18.7 8.4-18.7 18.7 0 7.2 4.1 13.4 10 16.5C136.9 47.5 60.3 127 60.3 224 60.3 229.2 64.6 233.5 69.8 233.5zM241.4 61.9c86.2 0 156.8 67.6 161.8 152.5H79.6C84.6 129.5 155.3 61.9 241.4 61.9zM193.1 92.6c-20.9 14.4-38.3 33.8-50.3 56.1 -2.5 4.6-0.8 10.4 3.9 12.9 1.4 0.8 3 1.1 4.5 1.1 3.4 0 6.7-1.8 8.4-5 10.6-19.7 25.9-36.8 44.3-49.4 4.3-3 5.4-8.9 2.5-13.3C203.4 90.7 197.5 89.6 193.1 92.6zM341.2 431.2l-122.8-71 -80.7-89.6H164l62.4 49.9c7.8 6.2 17.2 9.8 27.2 10.4 43.3 2.4 52.6-8.3 55.7-11.9 10-11.6 17.8-36 21.3-48.5H348c-6.1 23.5-15 73.7 9.8 103.3 3.4 4 9.4 4.6 13.5 1.2 4-3.4 4.6-9.4 1.2-13.5 -20.8-24.8-9.6-73.5-4.6-91h62.4c5.3 0 9.5-4.3 9.5-9.5s-4.3-9.5-9.5-9.5h-69.4 -37.4 -156 -51.2H52.7c-5.3 0-9.5 4.3-9.5 9.5s4.3 9.5 9.5 9.5h59.2l93.2 103.5c0.7 0.7 1.5 1.4 2.3 1.9l124.1 71.7c1.5 0.9 3.1 1.3 4.8 1.3 3.3 0 6.5-1.7 8.3-4.8C347.3 439.7 345.7 433.8 341.2 431.2zM294.8 306.6c-2.3 2.7-13.4 6.8-40.2 5.3 -6-0.3-11.6-2.5-16.3-6.3l-43.8-35h116.2C306.9 283 301 299.5 294.8 306.6zM462.3 379.9l-54.9-18.1c-4.7-1.5-9.8 0.7-11.7 5.2l-46.2 105.7c-1.1 2.5-1.1 5.3 0 7.7 1.1 2.5 3.2 4.3 5.7 5.2l54.9 18.1c1 0.3 2 0.5 3 0.5 4 0 7.7-2.5 9.1-6.6 1.7-5-1.1-10.4-6.1-12.1l-44.9-14.8 38.6-88.1 46.6 15.4c5 1.7 10.4-1.1 12.1-6.1C470 386.9 467.3 381.5 462.3 379.9z" /></svg></span>
<span class="txt"><span>Order Now</span></span>
</a>
</div>
</div>
</nav>
<!-- ==================================
Main content
=================================== --><main class="dzone-content czone"><div class="row sticky-position"><div class="large-24 columns"><div class="block-title blk-title"><h1>The Mills BBQ | Specials</h1></div></div></div><div id="row_SECTION_AQGKQSD9DL" class="row">
<div id="col_COLUMN_IIMPR1RMC6" class="large-12 columns large-push-6">
<figure id="img_BLOCK_WNW2BZPV9E" class="block-image blk-image lazy">
<img src="data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%20540%20540%27%3E%3C%2Fsvg%3E" data-src="/ressources/images/7ba3e4fa6638.jpg" width="540" height="540" loading="lazy" class="blk-image__image" />
</figure>
</div><div id="col_COLUMN_I539SQAM3A" class="large-12 columns">
</div>
</div><div id="row_SECTION_HFZCXIPUIM" class="row">
<div id="col_COLUMN_EDGTA3JLIQ" class="large-24 columns">
<div class="block-slider slider-design-2 " id="gallerydiv_4_2">
	<div class="owl-carousel bandeau01">
		<div class="item-wrapper">
			<div class="item-image">
				<div class="image owl-lazy" data-src="/ressources/images/c580b9b5bdf8.jpg" data-title="" data-description="" style=""></div>
			</div>
		</div>
		<div class="item-wrapper">
			<div class="item-image">
				<div class="image owl-lazy" data-src="/ressources/images/de35fbe337c0.jpg" data-title="" data-description="" style=""></div>
			</div>
		</div>
		<div class="item-wrapper">
			<div class="item-image">
				<div class="image owl-lazy" data-src="/ressources/images/bffa228ebbba.jpg" data-title="" data-description="" style=""></div>
			</div>
		</div>
		<div class="item-wrapper">
			<div class="item-image">
				<div class="image owl-lazy" data-src="/ressources/images/0c7560106054.jpg" data-title="" data-description="" style=""></div>
			</div>
		</div>
		<div class="item-wrapper">
			<div class="item-image">
				<div class="image owl-lazy" data-src="/ressources/images/bfcd26fa05ec.jpeg" data-title="" data-description="" style=""></div>
			</div>
		</div>
		<div class="item-wrapper">
			<div class="item-image">
				<div class="image owl-lazy" data-src="/ressources/images/e6dcbd8b95e4.jpeg" data-title="" data-description="" style=""></div>
			</div>
		</div>
		<div class="item-wrapper">
			<div class="item-image">
				<div class="image owl-lazy" data-src="/ressources/images/59182cfa9857.jpeg" data-title="" data-description="" style=""></div>
			</div>
		</div>
	</div>
</div></div>
</div><div id="row_SECTION_TKOW5NWZ0X" class="row sectionideal2-cta section-background-image full-width">
<div id="col_COLUMN_1TS7MXALAN" class="large-24 columns">
<div id="text_BLOCK_5NCKTWR87I" class="block-text blk-text emphasis">
<p style="text-align:center"><strong>Craving a mouth-watering </strong></p>
<p style="text-align:center">barbecue plate?</p>
</div>
<div id="bouton_BLOCK_U8BZ99M23R" class="block-button blk-button medium align-center text-center">
<a class="button blk-button__link" href="https://deliver.biz/carte/carte?key=a9d7853e58c8738e31047dac36dd0699db839448&c=AGCCND6317&ui=light&lang=en&noiframe=true" target="_blank">
<span class="txt blk-button__label"><span>Order Now</span></span>
</a>
</div>
</div>
</div><div id="row_SECTION_TIGH9RTDRE" class="row hide">
<div id="col_COLUMN_9X31YZUCFK" class="large-8 columns">
<figure id="img_BLOCK_Z3KXCG829E" class="block-image blk-image lazy">
<a href="/ressources/images/8198aaf1c8a6.jpg" class="blk-image__link lightbox"><img src="data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%20540%20540%27%3E%3C%2Fsvg%3E" data-src="/ressources/images/8198aaf1c8a6.jpg" width="540" height="540" loading="lazy" class="blk-image__image" /></a>
</figure>
</div><div id="col_COLUMN_9FAM66FUML" class="large-8 columns">
<figure id="img_BLOCK_PTV3YNVUN3" class="block-image blk-image lazy">
<a href="/ressources/images/d50fb7fe554d.jpg" class="blk-image__link lightbox"><img src="data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%20540%20540%27%3E%3C%2Fsvg%3E" data-src="/ressources/images/d50fb7fe554d.jpg" width="540" height="540" loading="lazy" class="blk-image__image" /></a>
</figure>
</div><div id="col_COLUMN_SS9CGU4UZC" class="large-8 columns">
<figure id="img_BLOCK_EM1TSB1187" class="block-image blk-image lazy">
<a href="/ressources/images/f3128a634d12.jpg" class="blk-image__link lightbox"><img src="data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%20640%20640%27%3E%3C%2Fsvg%3E" data-src="/ressources/images/f3128a634d12.jpg" width="640" height="640" loading="lazy" class="blk-image__image" /></a>
</figure>
</div>
</div><div id="row_SECTION_B8S3XNAP2N" class="row large-flex-middle hide">
<div id="col_COLUMN_7IK3NJ83NF" class="large-7 columns large-push-4">
<figure id="img_BLOCK_7VIWYCWQCO" class="block-image blk-image lazy">
<a href="/ressources/images/459743aa9464.jpeg" class="blk-image__link lightbox"><img src="data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%20764%201080%27%3E%3C%2Fsvg%3E" data-src="/ressources/images/459743aa9464.jpeg" width="764" height="1080" loading="lazy" class="blk-image__image" /></a>
</figure>
</div><div id="col_COLUMN_HB8DJOQC5Y" class="large-11 columns large-push-4 large-flex-middle medium-flex-middle">
<figure id="img_BLOCK_OWVELB245V" class="block-image blk-image lazy">
<a href="/ressources/images/fe7ea8432caf.jpeg" class="blk-image__link lightbox"><img src="data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%20540%20540%27%3E%3C%2Fsvg%3E" data-src="/ressources/images/fe7ea8432caf.jpeg" width="540" height="540" loading="lazy" class="blk-image__image" /></a>
</figure>
</div><div id="col_COLUMN_NB9VWMNLHS" class="large-6 columns">
</div>
</div></main><!-- ==================================
Subheader
=================================== --><aside class="dzone-subheader subheader"></aside>
<!-- ==================================
Side nav
=================================== --><aside class="dzone-sidenav sidenav"></aside>
<!-- ==================================
Prefooter
=================================== --><aside class="dzone-prefooter prefooter">
<div class="grid-template">
<div class="block-contact">
<p itemprop="name" class="contact-name">
The Mills BBQ
</p>
<div itemscope="" itemtype="http://schema.org/PostalAddress" itemprop="address" class="contact-address">
<p itemprop="streetAddress">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="16" height="16" viewBox="0 0 512 512" fill="#000000" class="icon-location2"><path class="color1" d="M256,0c-77.9,0-141.1,63.2-141.1,141.1c0,77.9,61.7,168.5,141.1,304.3C335.3,309.5,397.1,219,397.1,141.1 C397.1,63.2,333.9,0,256,0z M256,188.2c-27.9,0-50.6-22.7-50.6-50.6c0-27.9,22.7-50.6,50.6-50.6c27.9,0,50.6,22.7,50.6,50.6 C306.6,165.6,283.9,188.2,256,188.2z M410.4,437.8c0,13.3-6.7,38.3-51.4,56.6c-57.5,23.5-148.4,23.5-206,0 c-44.8-18.3-51.4-43.3-51.4-56.6c0-33.5,36.9-53.1,69.1-62.7c6.2,10.6,12.7,21.4,19.3,32.6c0.2,0.3,0.4,0.6,0.6,1 c-108.6,26.9-20.5,65.6,65.5,65.6c85.8,0,173.9-38.8,65.5-65.6c0.2-0.3,0.4-0.6,0.6-1c6.6-11.2,13.1-22,19.3-32.6 C373.5,384.7,410.4,404.4,410.4,437.8z" /></svg>104 Tremaine Rd</p>
<p>
<span itemprop="addressLocality">Milton, ON</span>
<span itemprop="postalCode">L9T 2W9</span>
</p>
<p><strong>(Pick-up only)</strong></p>
<p itemprop="addressCountry" class="hide">
Canada
</p>
</div>
<p class="contact-telephone">
</p>
<br />
<p><strong>Delivery anywhere in the GTA area (Delivery charge will be subjected to distance)</strong></p>
</div>
<div class="block-openhours">
<p>
Opening Hours
</p>
<ul>
<li>
<span class="day">Friday</span>
<span class="hours">4:30 PM - 12:30 AM</span>
</li>
<li>
<span class="day">Saturday</span>
<span class="hours">11:00 AM - 10:00 PM</span>
</li>
<li>
<span class="day">Sunday</span>
<span class="hours">12:00 PM - 08:00 PM</span>
</li>
</ul>
</div>
<nav class="block-nav footer-nav">
<p>
About
</p>
<ul>
              <li><a href="/" target="_self">Home</a></li>
              <li><a href="/contact.php" target="_self">Contact Us</a></li>
              <li><a href="/terms-conditions.php" target="_self">Terms and Conditions</a></li>
              <li><a href="/site-map.php" target="_self">Site Map</a></li>
</ul>
</nav>
<nav class="block-socialbar tiny style-rounded color-default">
<p>
Follow Us
</p>
<ul>
<li class="facebook">
<a itemprop="sameAs" rel="noreferrer" href="https://www.facebook.com/themillsbbq/photos/?ref=page_internal" title="facebook" target="_blank">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="16" height="16" viewBox="0 0 512 512" fill="#000000" class="icon-facebook1"><path class="color1" d="M293.5 494h-89.2V256h-59.5v-82l59.5 0 -0.1-48.3c0-66.9 18.1-107.6 97-107.6h65.6v82h-41c-30.7 0-32.2 11.5-32.2 32.9l-0.1 41.1h73.8l-8.7 82 -65 0L293.5 494z" /></svg>            </a>
</li>
<li class="instagram">
<a itemprop="sameAs" rel="noreferrer" href="https://www.instagram.com/themillsbbq/?hl=en" title="instagram" target="_blank">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="16" height="16" viewBox="0 0 512 512" fill="#000000" class="icon-instagram1"><path class="color1" d="M367.44,512H144.56C65.14,512,0.52,447.38,0.52,367.96V144.04C0.52,64.62,65.14,0,144.56,0h222.88 c79.42,0,144.04,64.62,144.04,144.04v223.92C511.48,447.38,446.86,512,367.44,512z M144.56,48.66c-52.59,0-95.38,42.79-95.38,95.38 v223.92c0,52.59,42.78,95.38,95.38,95.38h222.88c52.59,0,95.38-42.78,95.38-95.38V144.04c0-52.59-42.78-95.38-95.38-95.38H144.56z M256,389.35c-73.53,0-133.35-59.82-133.35-133.35S182.47,122.65,256,122.65S389.35,182.47,389.35,256S329.53,389.35,256,389.35z M256,171.31c-46.7,0-84.69,37.99-84.69,84.69s37.99,84.69,84.69,84.69s84.69-37.99,84.69-84.69S302.7,171.31,256,171.31z M392.32,86.23c-18.48,0-33.46,14.98-33.46,33.46s14.98,33.46,33.46,33.46c18.48,0,33.46-14.98,33.46-33.46 S410.8,86.23,392.32,86.23z" /></svg>            </a>
</li>
</ul>
</nav>
<div style="padding-bottom:104%" id="map_BLOCK_O5R989T8KT_614d562df3818" class="block-map blk-map">
<div id="gmap_map_BLOCK_O5R989T8KT_614d562df3818" class="planacces-map map_BLOCK_O5R989T8KT_614d562df3818 blk-map__planacces"></div>
</div>
</div>
</aside>
<!-- ==================================
Footer
=================================== --><footer class="dzone-footer"><div class="grid-template">
<div class="block-linkeo clearfix blk-linkeo"><span class="logo-linkeo blk-linkeo__logo" title="linkeo"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="51" height="20" viewBox="0 0 512 200" fill="#000000" class="icon-linkeo1"><path d="M456.4 144.4c23.5 11.9 45.8-5.6 52.8-27.8 7.4-23.5-1.5-55.6-25.2-65.4 -20.1-8.3-39.5 6.4-46.2 24.7 -0.4 0.8-0.6 1.6-0.9 2.5C431.8 100.6 433.2 132.6 456.4 144.4zM459.4 84.6c2.6-9.1 8.9-14.1 18.3-11 4.1 1.4 5.7 6.4 7 10 3.2 8.7 4 17.7 1.9 26.7 -2.5 10.5-11.8 18.2-22 11.9 -4.1-2.5-5.1-9.6-6.1-13.8C456.7 100.6 457.6 92.4 459.4 84.6z" /><path d="M407 140c12.8-7.9 1.1-28.1-11.8-20.2 -10.4 6.4-29.1 8.8-34.5-5.4 -0.3-0.8-0.6-1.8-0.9-2.7 14.2-1.7 28.3-3.6 42.5-5.8 5.5-0.8 7.9-6.5 8.6-11.2 1.7-12.9-2-26.4-10.7-36.1 -13.7-15.2-40.6-10.8-54 1.8 -16.6 15.7-13.8 51-3.7 69.4C354.7 152.5 387.9 151.8 407 140zM365.5 74.5c11.9-8.1 19.3 0.2 21.5 10.2 -9.6 1.4-19.2 2.7-28.8 3.8C359.1 82.6 361.3 77.4 365.5 74.5z" /><path d="M77.1 174.1c-16.7 1.9-35 3.2-52.2 1.3 -0.4-38.3-1.1-76.7-1.6-115 -0.2-15-23.5-15.1-23.3 0 0.6 41.7 1.4 83.4 1.7 125 0 4.8 3.5 10.3 8.6 11.2 21.7 4 45 3.1 66.8 0.7C91.9 195.8 92.1 172.5 77.1 174.1z" /><path d="M54.7 60.5c0.9 25.5 0.8 51 0.5 76.5 -0.2 15.1 23.1 15 23.3 0 0.3-25.5 0.4-51-0.5-76.5C77.5 45.5 54.2 45.4 54.7 60.5z" /><path d="M178.3 60.6c0.5 27.5 0.6 55 0.4 82.4 -16.9-28-35.3-55.4-47.3-85.7 -4.5-11.5-23.3-11-22.9 3.1 1.2 42.4 0.6 84.9 2.4 127.3 0.7 15 24 15.1 23.3 0 -1.1-25.5-1.3-50.9-1.6-76.4 15.8 27.2 33.5 53.5 46.9 81.9 5.2 11 21.5 5 21.8-5.9 1-42.3 1-84.5 0.3-126.8C201.4 45.6 178 45.5 178.3 60.6z" /><path d="M284.2 108.4c11.3-13.8 22.3-27.9 32.8-42.3 8.9-12.2-11.4-23.8-20.2-11.8 -13.8 18.9-28.6 37.3-43.8 55.2 -0.6-16.3-1.2-32.7-1.8-49 -0.5-15-23.9-15.1-23.3 0 1.6 42.3 3.4 84.8 3.5 127.1 0 15.1 23.4 15.1 23.3 0 0-14.5-0.3-29-0.7-43.5 4.7-5.5 9.5-11 14.2-16.5 12.1 21.6 23.7 43.6 35.2 65.6 7 13.3 27.1 1.5 20.2-11.8C310.7 156.9 297.9 132.4 284.2 108.4z" /><path d="M65.6 23.7c15.1 0 15.1-23.3 0-23.3C50.5 0.4 50.5 23.7 65.6 23.7z" /><path d="M497.4 169.7c-43.1 9.1-93.2 8.6-136.6 1 -14.7-2.6-21 19.9-6.2 22.5 47.7 8.4 101.5 9.1 149-0.9C518.3 189.1 512.1 166.6 497.4 169.7z" /></svg></span></div>
</div>
<div class="scrollUp">
<span class="ico"><svg width="16" height="16" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" class="icon-arrowTop4"><polygon class="color1" points="0,375.7 16.6,392.3 256,152.9 495.4,392.3 512,375.7 256,119.7 " /></svg>
</span>
</div>
</footer>
<!-- ==================================
Hero Container
=================================== --><section class="dzone-herocontainer hero-container">
<div class="block-slider">
<div class="owl-carousel header">
<div class="item-wrapper">
	<div class="item-image">
		<div class="image owl-lazy" data-src="/ressources/images/8c02ec846d67.png" data-title="" data-description="" ></div>
	</div>
</div>
</div>
</div>
</section>
<!-- ==================================
Mobile Tab-bar
=================================== --><nav id="tab-mobile" class="tab-bar fixed dzone-tabmobile">
<div class="center-small full-width">
<figure class="block-logo">
<a href="/">
<span class="logo"><img itemprop="logo" alt="The Mills BBQ" src="ressources/images/740341b4ebff.png" /></span>
<span class="name" itemprop="name">The Mills BBQ</span>
</a>
</figure>
</div>
</nav>
</div>
<!-- ==================================
Mobile Navigation
=================================== -->
<div class="dzone-mobilenav">
<div id="tab-mobile-bottom" class="fixed tab-mobile-bottom">
<nav class="tab-bar">
<div class="block-button tiny text-center vertical tab-mobile-bottom-toggle">
<a class="button">
<span class="ico"><svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" class="icon-menu2"><path class="color1" d="M15.4,1.8v1.2H0.6V1.8C0.6,1.8,15.4,1.8,15.4,1.8z M0.6,14.2h8.7v-1.2H0.6V14.2z M0.6,8.6h14.8V7.4H0.6V8.6z" /></svg></span>
<span class="txt"><span>Menu</span></span>
</a>
</div>
<div class="block-button tiny text-center vertical">
<a href="https://www.google.com/maps/place/104+Tremaine+Rd,+L9T+2W9+Milton/" target="_blank" class="button">
<span class="ico"><svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" class="icon-location6"><path class="color1" d="M254.8 229.6" /><path class="color1" d="M254.8 229.6" /><path class="color1" d="M8,16c-1.91,0-6.08-5.59-6.08-9.79C1.92,2.78,4.65,0,8,0s6.08,2.78,6.08,6.21C14.08,10.41,9.91,16,8,16z M8,1.25 c-2.66,0-4.83,2.23-4.83,4.95c0,3.78,3.88,8.5,4.83,8.54c0.95-0.04,4.83-4.76,4.83-8.54C12.83,3.48,10.66,1.25,8,1.25z M8.32,6.66 c0.1-0.04,0.19-0.1,0.26-0.18C8.75,6.33,8.83,6.12,8.83,5.9c0-0.22-0.08-0.43-0.25-0.6c-0.31-0.31-0.86-0.31-1.17,0 C7.25,5.47,7.17,5.68,7.17,5.9c0,0.22,0.08,0.43,0.25,0.58C7.57,6.64,7.78,6.73,8,6.73C8.11,6.73,8.22,6.71,8.32,6.66z" /></svg></span>
<span class="txt"><span>Map</span></span>
</a>
</div>
<div class="block-button button-style2">
<a href="https://deliver.biz/carte/carte?key=a9d7853e58c8738e31047dac36dd0699db839448&c=AGCCND6317&ui=light&lang=en&noiframe=true" target="_blank" class="button">
<span class="txt"><span>Order Now</span></span>
</a>
</div>
</nav>
<div class="tab-mobile-bottom-scroll-zone">
<nav class="bottom-bar-section">
<ul>
              <li><a href="/" target="_self">Home</a></li>
              <li><a href="/specials.php" target="_self">Specials</a></li>
              <li><a href="/menu.php" target="_self">Menu</a></li>
              <li><a href="https://deliver.biz/carte/carte?key=a9d7853e58c8738e31047dac36dd0699db839448&amp;c=AGCCND6317&amp;ui=light&amp;lang=en&amp;noiframe=true" target="_blank">Order Now</a></li>
              <li><a href="/contact.php" target="_self">Contact Us</a></li>
              <li><a href="/terms-conditions.php" target="_self">Terms and Conditions</a></li>
              <li><a href="/site-map.php" target="_self">Site Map</a></li>
</ul>
</nav>
<div class="block-contact">
<p itemprop="name" class="contact-name">
The Mills BBQ
</p>
<div itemscope="" itemtype="http://schema.org/PostalAddress" itemprop="address" class="contact-address">
<p itemprop="streetAddress">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="16" height="16" viewBox="0 0 512 512" fill="#000000" class="icon-location2"><path class="color1" d="M256,0c-77.9,0-141.1,63.2-141.1,141.1c0,77.9,61.7,168.5,141.1,304.3C335.3,309.5,397.1,219,397.1,141.1 C397.1,63.2,333.9,0,256,0z M256,188.2c-27.9,0-50.6-22.7-50.6-50.6c0-27.9,22.7-50.6,50.6-50.6c27.9,0,50.6,22.7,50.6,50.6 C306.6,165.6,283.9,188.2,256,188.2z M410.4,437.8c0,13.3-6.7,38.3-51.4,56.6c-57.5,23.5-148.4,23.5-206,0 c-44.8-18.3-51.4-43.3-51.4-56.6c0-33.5,36.9-53.1,69.1-62.7c6.2,10.6,12.7,21.4,19.3,32.6c0.2,0.3,0.4,0.6,0.6,1 c-108.6,26.9-20.5,65.6,65.5,65.6c85.8,0,173.9-38.8,65.5-65.6c0.2-0.3,0.4-0.6,0.6-1c6.6-11.2,13.1-22,19.3-32.6 C373.5,384.7,410.4,404.4,410.4,437.8z" /></svg>104 Tremaine Rd</p>
<p>
<span itemprop="addressLocality">Milton, ON</span>
<span itemprop="postalCode">L9T 2W9</span>
</p>
<p><strong>(Pick-up only)</strong></p>
<p itemprop="addressCountry" class="hide">
Canada
</p>
</div>
<p class="contact-telephone">
</p>
<br />
<p><strong>Delivery anywhere in the GTA area (Delivery charge will be subjected to distance)</strong></p>
</div>
<nav class="block-socialbar tiny style-rounded color-default">
<ul>
<li class="facebook">
<a itemprop="sameAs" rel="noreferrer" href="https://www.facebook.com/themillsbbq/photos/?ref=page_internal" title="facebook" target="_blank">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="16" height="16" viewBox="0 0 512 512" fill="#000000" class="icon-facebook1"><path class="color1" d="M293.5 494h-89.2V256h-59.5v-82l59.5 0 -0.1-48.3c0-66.9 18.1-107.6 97-107.6h65.6v82h-41c-30.7 0-32.2 11.5-32.2 32.9l-0.1 41.1h73.8l-8.7 82 -65 0L293.5 494z" /></svg>            </a>
</li>
<li class="instagram">
<a itemprop="sameAs" rel="noreferrer" href="https://www.instagram.com/themillsbbq/?hl=en" title="instagram" target="_blank">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="16" height="16" viewBox="0 0 512 512" fill="#000000" class="icon-instagram1"><path class="color1" d="M367.44,512H144.56C65.14,512,0.52,447.38,0.52,367.96V144.04C0.52,64.62,65.14,0,144.56,0h222.88 c79.42,0,144.04,64.62,144.04,144.04v223.92C511.48,447.38,446.86,512,367.44,512z M144.56,48.66c-52.59,0-95.38,42.79-95.38,95.38 v223.92c0,52.59,42.78,95.38,95.38,95.38h222.88c52.59,0,95.38-42.78,95.38-95.38V144.04c0-52.59-42.78-95.38-95.38-95.38H144.56z M256,389.35c-73.53,0-133.35-59.82-133.35-133.35S182.47,122.65,256,122.65S389.35,182.47,389.35,256S329.53,389.35,256,389.35z M256,171.31c-46.7,0-84.69,37.99-84.69,84.69s37.99,84.69,84.69,84.69s84.69-37.99,84.69-84.69S302.7,171.31,256,171.31z M392.32,86.23c-18.48,0-33.46,14.98-33.46,33.46s14.98,33.46,33.46,33.46c18.48,0,33.46-14.98,33.46-33.46 S410.8,86.23,392.32,86.23z" /></svg>            </a>
</li>
</ul>
</nav>
</div>
<div class="tab-mobile-bottom-toggle close-trigger">
<span class="ico"><svg width="16" height="16" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" class="icon-plus1"><path class="color1" d="M386,234.5H277.5V126c0-11.9-9.6-21.5-21.5-21.5s-21.5,9.6-21.5,21.5v108.5H126c-11.9,0-21.5,9.6-21.5,21.5 s9.6,21.5,21.5,21.5h108.5V386c0,11.9,9.6,21.5,21.5,21.5s21.5-9.6,21.5-21.5V277.5H386c11.9,0,21.5-9.6,21.5-21.5 S397.9,234.5,386,234.5z" /></svg></span>
</div>
</div>
</div>
<div id="tinyModal" class="reveal-modal tiny" data-reveal></div>
<div id="smallModal" class="reveal-modal small" data-reveal></div>
<div id="mediumModal" class="reveal-modal medium" data-reveal></div>
<div id="largeModal" class="reveal-modal large" data-reveal></div>
<div id="xlargeModal" class="reveal-modal xlarge" data-reveal></div>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyACfYfCcJn5WlETkaTDI1QFd5OkVjvJxsQ"></script>
<script src="/AMBIANCE_FBNWQMW54V_bambooBay-grid/js/build/ideo3.min.js"></script>
<script src="/AMBIANCE_FBNWQMW54V_bambooBay-grid/template/slider/header/owl.option.header.js"></script>
<script src="/AMBIANCE_FBNWQMW54V_bambooBay-grid/template/js/template.min.js"></script>
<script src="/js/PAGE_EI9BTFC1R8.min.js?v=1632458286"></script><script>Epeius.addTracker( { name: 'Google Analytics', id: 'ga', cookies: ['_ga', '_gat', '_gid'], config: {key: 'UA-198112569-36'} } );</script><script>Epeius.addTracker( { name: 'Google Ads Remarketing', id: 'gawr', config: {key: '985359031', params: {cbtn: 'ba2552892889e25acf587c1b74004b2e2f5aca9a', dpt: 'L9T 2W9', region: 'ON', pays:'CA', cat: 'loisir-tourisme', souscat: 'restaurants'}} } );</script></body></html>