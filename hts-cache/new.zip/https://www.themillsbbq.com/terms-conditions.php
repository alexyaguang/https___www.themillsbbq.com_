<!DOCTYPE html>
<html class="no-js" lang="en"><head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><meta lang="" name="keywords" content="Bbq food truck,Milton,The Mills BBQ" /><meta lang="" name="description" content="Bbq food truck, Milton, The Mills BBQ, 230 St-Mary L9T 1M2"  /><meta name="robots" content="index, follow" /><title>Bbq food truck Milton</title><!--[if lt IE 9]>
<script src="/AMBIANCE_FBNWQMW54V_bambooBay-grid/js/vendor/html5shiv.min.js"></script>
<![endif]-->
<link href="/css/ambiance.min.css?v=1632458181" rel="stylesheet" type="text/css" /></head><body itemscope itemtype="http://schema.org/Organization" class="content gridAmbiance" id="PAGE_3V7GW8COY5">
<div class="stickyfooter">
<!-- ==================================
Tab mobile spacer
=================================== -->
<div id="tab-mobile-spacer"></div>
<!-- ==================================
Header
=================================== -->
<input id="publicPath" value="" hidden /><header class="dzone-header">
<div class="grid-template">
<figure class="block-logo">
<a href="/">
<span class="logo"><img itemprop="logo" alt="The Mills BBQ" src="ressources/images/d161b2f85b7f.png" /></span>
</a>
</figure>
<div class="block-slogan">
<p class="slogan">
An extravagant barbecue experience
</p>
</div>
<div class="block-call-to-action">
<div class="block-button button-style2">
<a href="https://deliver.biz/carte/carte?key=a9d7853e58c8738e31047dac36dd0699db839448&c=AGCCND6317&ui=light&lang=en&noiframe=true" target="_blank" class="button">
<span class="ico"><svg width="16" height="16" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" class="icon-Misc06"><path class="color1" d="M69.8 233.5H413c5.3 0 9.5-4.3 9.5-9.5 0-97-76.6-176.4-172.5-180.9 6-3.1 10-9.4 10-16.5 0-10.3-8.4-18.7-18.7-18.7 -10.3 0-18.7 8.4-18.7 18.7 0 7.2 4.1 13.4 10 16.5C136.9 47.5 60.3 127 60.3 224 60.3 229.2 64.6 233.5 69.8 233.5zM241.4 61.9c86.2 0 156.8 67.6 161.8 152.5H79.6C84.6 129.5 155.3 61.9 241.4 61.9zM193.1 92.6c-20.9 14.4-38.3 33.8-50.3 56.1 -2.5 4.6-0.8 10.4 3.9 12.9 1.4 0.8 3 1.1 4.5 1.1 3.4 0 6.7-1.8 8.4-5 10.6-19.7 25.9-36.8 44.3-49.4 4.3-3 5.4-8.9 2.5-13.3C203.4 90.7 197.5 89.6 193.1 92.6zM341.2 431.2l-122.8-71 -80.7-89.6H164l62.4 49.9c7.8 6.2 17.2 9.8 27.2 10.4 43.3 2.4 52.6-8.3 55.7-11.9 10-11.6 17.8-36 21.3-48.5H348c-6.1 23.5-15 73.7 9.8 103.3 3.4 4 9.4 4.6 13.5 1.2 4-3.4 4.6-9.4 1.2-13.5 -20.8-24.8-9.6-73.5-4.6-91h62.4c5.3 0 9.5-4.3 9.5-9.5s-4.3-9.5-9.5-9.5h-69.4 -37.4 -156 -51.2H52.7c-5.3 0-9.5 4.3-9.5 9.5s4.3 9.5 9.5 9.5h59.2l93.2 103.5c0.7 0.7 1.5 1.4 2.3 1.9l124.1 71.7c1.5 0.9 3.1 1.3 4.8 1.3 3.3 0 6.5-1.7 8.3-4.8C347.3 439.7 345.7 433.8 341.2 431.2zM294.8 306.6c-2.3 2.7-13.4 6.8-40.2 5.3 -6-0.3-11.6-2.5-16.3-6.3l-43.8-35h116.2C306.9 283 301 299.5 294.8 306.6zM462.3 379.9l-54.9-18.1c-4.7-1.5-9.8 0.7-11.7 5.2l-46.2 105.7c-1.1 2.5-1.1 5.3 0 7.7 1.1 2.5 3.2 4.3 5.7 5.2l54.9 18.1c1 0.3 2 0.5 3 0.5 4 0 7.7-2.5 9.1-6.6 1.7-5-1.1-10.4-6.1-12.1l-44.9-14.8 38.6-88.1 46.6 15.4c5 1.7 10.4-1.1 12.1-6.1C470 386.9 467.3 381.5 462.3 379.9z" /></svg></span>
<span class="txt"><span>Order Now</span></span>
</a>
</div>
</div>
</div>
</header>
<div class="HeaderFloatingButton">
<div class="block-button">
<a href="https://www.ubereats.com/ca/toronto/food-delivery/the-mills/ynJr-olTSxy6oYNmxKrHAA?pl=JTdCJTIyYWRkcmVzcyUyMiUzQSUyMlRoZSUyME1pbGxzJTIwYXQlMjBKZXJzZXklMjBHYXJkZW5zJTIyJTJDJTIycmVmZXJlbmNlJTIyJTNBJTIyQ2hJSml4UWVOSUJOd29rUkl0WFVWOHVqTGpRJTIyJTJDJTIycmVmZXJlbmNlVHlwZSUyMiUzQSUyMmdvb2dsZV9wbGFjZXMlMjIlMkMlMjJsYXRpdHVkZSUyMiUzQTQwLjY2MTI1ODMlMkMlMjJsb25naXR1ZGUlMjIlM0EtNzQuMTcxNDg1JTdE" target="_blank">
<img itemprop="logo" alt="The Mills BBQ" src="ressources/images/01caa85cbad6.png" />
</a>
</div>
<div class="block-button button-style2">
<a href="https://www.doordash.com/store/the-mills-milton-1167628" target="_blank">
<img itemprop="logo" alt="The Mills BBQ" src="ressources/images/4c5b188b4db1.png" />
</a>
</div>
<div class="block-button button-style2">
<a href="https://foodling.co/stores/the-mills-bbq" target="_blank">
<img itemprop="logo" alt="Foodling" src="ressources/images/39100cc533f8.png" />
</a>
</div>
</div><!-- ==================================
Top Nav
=================================== --><nav class="dzone-topnav top-bar top-nav block-nav sticky-position" data-topbar="" data-options="custom_back_text: false">
<div class="grid-template">
<figure class="block-logo">
<a href="/">
<span class="logo"><img itemprop="logo" alt="The Mills BBQ" src="ressources/images/740341b4ebff.png" /></span>
<span class="name" itemprop="name">The Mills BBQ</span>
</a>
</figure>
<div class="top-bar-section">
<ul>
              <li><a href="/" target="_self">Home</a></li>
              <li><a href="/specials.php" target="_self">Specials</a></li>
              <li><a href="/menu.php" target="_self">Menu</a></li>
              <li><a href="https://deliver.biz/carte/carte?key=a9d7853e58c8738e31047dac36dd0699db839448&amp;c=AGCCND6317&amp;ui=light&amp;lang=en&amp;noiframe=true" target="_blank">Order Now</a></li>
              <li><a href="/contact.php" target="_self">Contact Us</a></li>
</ul>
</div>
<div class="block-button">
<a href="https://deliver.biz/carte/carte?key=a9d7853e58c8738e31047dac36dd0699db839448&c=AGCCND6317&ui=light&lang=en&noiframe=true" target="_blank" class="button">
<span class="ico"><svg width="16" height="16" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" class="icon-Misc06"><path class="color1" d="M69.8 233.5H413c5.3 0 9.5-4.3 9.5-9.5 0-97-76.6-176.4-172.5-180.9 6-3.1 10-9.4 10-16.5 0-10.3-8.4-18.7-18.7-18.7 -10.3 0-18.7 8.4-18.7 18.7 0 7.2 4.1 13.4 10 16.5C136.9 47.5 60.3 127 60.3 224 60.3 229.2 64.6 233.5 69.8 233.5zM241.4 61.9c86.2 0 156.8 67.6 161.8 152.5H79.6C84.6 129.5 155.3 61.9 241.4 61.9zM193.1 92.6c-20.9 14.4-38.3 33.8-50.3 56.1 -2.5 4.6-0.8 10.4 3.9 12.9 1.4 0.8 3 1.1 4.5 1.1 3.4 0 6.7-1.8 8.4-5 10.6-19.7 25.9-36.8 44.3-49.4 4.3-3 5.4-8.9 2.5-13.3C203.4 90.7 197.5 89.6 193.1 92.6zM341.2 431.2l-122.8-71 -80.7-89.6H164l62.4 49.9c7.8 6.2 17.2 9.8 27.2 10.4 43.3 2.4 52.6-8.3 55.7-11.9 10-11.6 17.8-36 21.3-48.5H348c-6.1 23.5-15 73.7 9.8 103.3 3.4 4 9.4 4.6 13.5 1.2 4-3.4 4.6-9.4 1.2-13.5 -20.8-24.8-9.6-73.5-4.6-91h62.4c5.3 0 9.5-4.3 9.5-9.5s-4.3-9.5-9.5-9.5h-69.4 -37.4 -156 -51.2H52.7c-5.3 0-9.5 4.3-9.5 9.5s4.3 9.5 9.5 9.5h59.2l93.2 103.5c0.7 0.7 1.5 1.4 2.3 1.9l124.1 71.7c1.5 0.9 3.1 1.3 4.8 1.3 3.3 0 6.5-1.7 8.3-4.8C347.3 439.7 345.7 433.8 341.2 431.2zM294.8 306.6c-2.3 2.7-13.4 6.8-40.2 5.3 -6-0.3-11.6-2.5-16.3-6.3l-43.8-35h116.2C306.9 283 301 299.5 294.8 306.6zM462.3 379.9l-54.9-18.1c-4.7-1.5-9.8 0.7-11.7 5.2l-46.2 105.7c-1.1 2.5-1.1 5.3 0 7.7 1.1 2.5 3.2 4.3 5.7 5.2l54.9 18.1c1 0.3 2 0.5 3 0.5 4 0 7.7-2.5 9.1-6.6 1.7-5-1.1-10.4-6.1-12.1l-44.9-14.8 38.6-88.1 46.6 15.4c5 1.7 10.4-1.1 12.1-6.1C470 386.9 467.3 381.5 462.3 379.9z" /></svg></span>
<span class="txt"><span>Order Now</span></span>
</a>
</div>
</div>
</nav>
<!-- ==================================
Main content
=================================== --><main class="dzone-content czone"><div class="row sticky-position"><div class="large-24 columns"><div class="block-title blk-title"><h1>Terms and Conditions</h1></div></div></div><div id="row_SECTION_HO4OBTSPIO" class="row">
<div id="col_COLUMN_GHTA5POVYH" class="large-24 columns">
<div id="legacy_BLOCK_QK2KU3RLI0">
<div class="block-termsandconditions blk-termsandconditions twocolumns">
<div class="part-1">
<h2>1. Statement</h2>
<p>1.1. We recognize that protecting privacy is everyone's concern and for that reason, we are committed to keeping our user’s information confidential. This Privacy Policy not only explains how we collect, share and use any information related to your personal data when you use our website but also how you can access, update or otherwise take control of your Personal Information.</p>
<p>1.2. Your use of this site constitutes your agreement to this Privacy Policy.</p>
<h2>2. Definitions</h2>
<p>2.1. "Personal Information" is recorded information about an identifiable individual but excludes any information that is not considered as such by Privacy Laws</p>
<p>2.2. "Privacy Laws" means the Act Respecting the Protection of Personal Information in the Private Sector, S.Q. P-39.1 and the Personal Information Protection and Electronic Documents Act, S.C. 2000, C.5. and their respective regulations from their enforcement bodies.</p>
<p>2.3. "Privacy Policy" means the present Privacy Policy for the collection, use, disclosure, retention and destruction of Personal Information in accordance with the Privacy Laws.</p>
<h2>3. Discretion</h2>
<p>Some provisions of this Privacy Policy may exceed regulatory requirements. In such circumstance, we have full discretion with respect to their application.</p>
<h2>4. Personal Information</h2>
<p>4.1. For purposes of this Privacy Policy, Personal Information is information about you that can be used to identify you. When you interact with us through our website, we may collect Personal Information such as, but not limited to:</p>
<ul>
<li>4.1.1.Full name, age, date of birth, gender and marital status (if applicable);</li>
<li>4.1.2.Billing and delivery postal addresses;</li>
<li>4.1.3.Payment information such as credit/debit card numbers, security code numbers and other related billing information;</li>
<li>4.1.4.Phone numbers (including mobile phone) and e-mail details;</li>
<li>4.1.5.Cookies, should you choose to accept them when consulting our website;</li>
<li>4.1.6.User name and password;</li>
<li>4.1.7.Information retrieved while browsing our website, your IP address, operating system and browser type, device type and time zone setting;</li>
<li>4.1.8.The date and time of your visit to our website;</li>
<li>4.1.9.The pages of our website that you access;</li>
<li>4.1.10. The documents you retrieved and any other correspondence with us;</li>
<li>4.1.11. All other information relevant to the services we are providing.</li>
</ul>
<h2>5. Cookies</h2>
<p>5.1. Our website uses cookies. A cookie is a small piece of information that is stored on a computer for the purpose of identifying that browser during interaction on the website. Cookies may be used to store items such as identifiers and user preferences. Our service providers use cookies and those cookies may be stored on your computer when you visit our website.</p>
<p>5.2. Cookies are considered "persistent" when stored by a web browser. These cookies remain valid until their set expiry date, unless the user deleted them prior to said expiry date. Cookies are considered "session cookies" in the case they expire at the end of the user session when the browser is closed. While cookies do not typically contain information that personally identifies a user, Personal Information that we store about a user may be connected to the information stored in and obtained from cookies.</p>
<p>5.3. On our website, we use cookies to:</p>
<ul>
<li>5.3.1.Identify you when you visit our website;</li>
<li>5.3.2.Help us manage the content contained our website;</li>
<li>5.3.3.Help creators manage content while organizing and updating the website;</li>
<li>5.3.4.Store information about your preferences and to personalize our website for you;</li>
<li>5.3.5. Use them as part of the security measures used to protect user accounts, including preventing fraudulent use of login information, and in general to protect our website and services;</li>
<li>5.3.6.Help us analyze the use and performance of our website and services;</li>
<li>5.3.7.Manage the promotion of our services, in order to attract interest and engagement.</li>
</ul>
<p>5.4. If you do not wish cookies to be used, your browser's options may be set to refuse cookies and/or delete cookies.</p>
<p><a href="#openRGPDSettings" onclick="Epeius.openSettings(); return false;">Set cookies options</a>.</p>
<h2>6. Information collected and its purpose</h2>
<p>6.1. Personal Information will only be collected with your consent, such as information voluntarily provided to us through our website. We strongly believe in both minimizing the data we collect and limiting its use and purpose to only that for which we have been given permission, as necessary to deliver the services you purchase or interact with, or as we might be required or permitted for legal compliance, government request, court orders or other lawful purposes</p>
<p>6.2. Personal Information to manage our business and maintain and develop further relationships. Collecting this information enables us to better understand the visitors who come to our website and what content on our website is of interest to them. Purposes for which we collect Personal Information include but are not limited to :</p>
<ul>
<li>6.2.1.Respond to your requests, comments or questions;</li>
<li>6.2.2.To process orders or to receive information about our website, service or product;</li>
<li>6.2.3.To improve the content, appearance and utility of the website and to trace our visitors' use of the website for internal inquiry purposes;</li>
<li>6.2.4.To provide any necessary notices and to notify our users of updates to the website;</li>
<li>6.2.5.With your consent, to send email offers, announcements, or newsletters to your email address and help us create content that is most relevant to you;</li>
<li>6.2.6.To execute our obligations arising from a contract entered into between yourself (the user) and us;</li>
<li>6.2.7.Management analysis, forecasting, business planning and transactions, ensuring our compliance with applicable laws and regulations;</li>
<li>6.2.8.For research, statistical and other purposes (such as improving our website, products and services) or measuring the effectiveness of our advertising.</li>
<li>6.3. If we are required to use or disclose your Personal Information for a purpose that differs from the purpose described herein, we will obtain your consent before using or disclosing the Personal Information.</li>
</ul>
</div>
<div class="part-2">
<h2>7. Data storage and security</h2>
<p>The Personal Information that we collect is stored in our servers.Once we receive personal data from you, we will use strict procedures and take reasonable administrative, technical and physical safeguards to protect this information from misuse, loss, unauthorised access, modification or disclosure to ensure that personal data remains confidential.</p>
<p>7.1. We implemented the customary security safeguards that are appropriate to the sensitivity of the information collected, including the physical, organizational and technological measures. These measures restrict access to your Personal Information from anyone who is not authorized to have access to it.</p>
<p>7.2. We will limit access to Personal Information about you to only those employees who need that information to provide products or services to you. Personal Information will only be used or disclosed for the purposes for which it was collected with consent and will be kept as long as required to serve those purposes.</p>
<p>7.3. Notwithstanding the foregoing, you should be aware that, no data transmission of information or other publicly accessible communications networks over the internet can be guaranteed to be 100% secure, and therefore, we cannot ensure or warrant the security of any such information.</p>
<h2>8. Responsibility</h2>
<p>8.1. We are responsible for the Personal Information collected from our users. In order to properly control the information processed, kept and used. We have appointed LINKEO to ensure our compliance with the Privacy Laws.</p>
<p>8.2. The Mills BBQ</p>
<ul>
<li>8.2.1.Address:104 Tremaine Rd Milton L9T 2W9</li>
<li>8.2.2.Telephone:905-699-0729</li>
</ul>
<p>8.3. Appointed contact:</p>
<ul>
<li>8.3.1.Name:Brendon Wilson</li>
<li>8.3.2.Address:104 Tremaine Rd Milton L9T 2W9</li>
<li>8.3.3.Telephone:905-699-0729</li>
</ul>
<h2>9. Disclosure and retention of your Personal Information</h2>
<p>9.1. We will not sell, rent or dispose in any manner, your Person Information to third parties except as disclosed in this Privacy Policy or agreed upon individually in a separate agreement.</p>
<p>9.2. Any complaint, issue or problem that we become aware of that violates this Privacy Policy will be treated as confidential. However, some disclosures may be necessary to resolve the issues and implement appropriate solutions.</p>
<p>9.3. We retain Personal Information we collect from you where we have an ongoing business and need to do so, for example, to provide you with a service you have requested or to comply with applicable legal, tax or accounting requirements. We keep your Personal Information in a form that allows us to identify you for as long as necessary to achieve the purposes for which we are processing your data and do not store your data for longer, unless we must comply with applicable laws.</p>
<p>9.4. Personal Information that is no longer required to fulfil the identified purposes will be destroyed, erased, or made anonymous.</p>
<h2>10. Access to your Personal Information</h2>
<p>10.1. You have the right to access, update, and correct inaccuracies in your Personal Information in our custody and control, subject to certain exceptions prescribed by law. You may request that: (i) we correct or update any such Personal Information; or (ii) such Personal Information be unsubscribed from the email marketing database.</p>
<p>10.2. If you wish to update your Personal Information, we invite you to contact us by any method provided for in section 8.2. When contacting us, we may request Personal Information to verify your identity and in order to be sure we handle your request correctly.</p>
<p>10.3. If you make a request to delete your Personal Information and that data is necessary for the products or services you have purchased and/or use, the request will be honored only to the extent it is no longer necessary for any services purchased and/or used, or required for business purposes or legal or contractual record keeping requirements.</p>
<p>10.4. In the event that you have provided your consent to collect and use your Personal Information, you may make a withdrawal of consent.</p>
<h2>11. Failure to provide Personal Information</h2>
<p>11.1. When we need to collect Personal Information by law or in order to provide our services and you fail to provide the information requested, we may not be able to carry out the services in which you have contracted us to do. In these circumstances we may have to cancel our agreement or contract.</p>
<p>11.2. We will notify you in the case of cancelation due to failure to provide Personal Information</p>
<h2>12. Transparency</h2>
<p>12.1. We are committed to being transparent with regard to the Personal Information we collect, use and store. We invite you to contact us using any of the methods provided for in section 8.2 with any questions you may have.</p>
<h2>13. Changes to this Privacy Policy</h2>
<p>13.1. This Policy is effective as of 8th april 2021, and supersedes all prior versions.</p>
<p>13.2. We reserve the right to change this Privacy Policy when appropriate and without prior notice. We therefore encourage you to refer back to this policy on a regular basis.</p>
</div>
</div>
</div>
</div>
</div></main><!-- ==================================
Subheader
=================================== --><aside class="dzone-subheader subheader"></aside>
<!-- ==================================
Side nav
=================================== --><aside class="dzone-sidenav sidenav"></aside>
<!-- ==================================
Prefooter
=================================== --><aside class="dzone-prefooter prefooter">
<div class="grid-template">
<div class="block-contact">
<p itemprop="name" class="contact-name">
The Mills BBQ
</p>
<div itemscope="" itemtype="http://schema.org/PostalAddress" itemprop="address" class="contact-address">
<p itemprop="streetAddress">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="16" height="16" viewBox="0 0 512 512" fill="#000000" class="icon-location2"><path class="color1" d="M256,0c-77.9,0-141.1,63.2-141.1,141.1c0,77.9,61.7,168.5,141.1,304.3C335.3,309.5,397.1,219,397.1,141.1 C397.1,63.2,333.9,0,256,0z M256,188.2c-27.9,0-50.6-22.7-50.6-50.6c0-27.9,22.7-50.6,50.6-50.6c27.9,0,50.6,22.7,50.6,50.6 C306.6,165.6,283.9,188.2,256,188.2z M410.4,437.8c0,13.3-6.7,38.3-51.4,56.6c-57.5,23.5-148.4,23.5-206,0 c-44.8-18.3-51.4-43.3-51.4-56.6c0-33.5,36.9-53.1,69.1-62.7c6.2,10.6,12.7,21.4,19.3,32.6c0.2,0.3,0.4,0.6,0.6,1 c-108.6,26.9-20.5,65.6,65.5,65.6c85.8,0,173.9-38.8,65.5-65.6c0.2-0.3,0.4-0.6,0.6-1c6.6-11.2,13.1-22,19.3-32.6 C373.5,384.7,410.4,404.4,410.4,437.8z" /></svg>104 Tremaine Rd</p>
<p>
<span itemprop="addressLocality">Milton, ON</span>
<span itemprop="postalCode">L9T 2W9</span>
</p>
<p><strong>(Pick-up only)</strong></p>
<p itemprop="addressCountry" class="hide">
Canada
</p>
</div>
<p class="contact-telephone">
</p>
<br />
<p><strong>Delivery anywhere in the GTA area (Delivery charge will be subjected to distance)</strong></p>
</div>
<div class="block-openhours">
<p>
Opening Hours
</p>
<ul>
<li>
<span class="day">Friday</span>
<span class="hours">4:30 PM - 12:30 AM</span>
</li>
<li>
<span class="day">Saturday</span>
<span class="hours">11:00 AM - 10:00 PM</span>
</li>
<li>
<span class="day">Sunday</span>
<span class="hours">12:00 PM - 08:00 PM</span>
</li>
</ul>
</div>
<nav class="block-nav footer-nav">
<p>
About
</p>
<ul>
              <li><a href="/" target="_self">Home</a></li>
              <li><a href="/contact.php" target="_self">Contact Us</a></li>
              <li><a href="/terms-conditions.php" target="_self">Terms and Conditions</a></li>
              <li><a href="/site-map.php" target="_self">Site Map</a></li>
</ul>
</nav>
<nav class="block-socialbar tiny style-rounded color-default">
<p>
Follow Us
</p>
<ul>
<li class="facebook">
<a itemprop="sameAs" rel="noreferrer" href="https://www.facebook.com/themillsbbq/photos/?ref=page_internal" title="facebook" target="_blank">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="16" height="16" viewBox="0 0 512 512" fill="#000000" class="icon-facebook1"><path class="color1" d="M293.5 494h-89.2V256h-59.5v-82l59.5 0 -0.1-48.3c0-66.9 18.1-107.6 97-107.6h65.6v82h-41c-30.7 0-32.2 11.5-32.2 32.9l-0.1 41.1h73.8l-8.7 82 -65 0L293.5 494z" /></svg>            </a>
</li>
<li class="instagram">
<a itemprop="sameAs" rel="noreferrer" href="https://www.instagram.com/themillsbbq/?hl=en" title="instagram" target="_blank">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="16" height="16" viewBox="0 0 512 512" fill="#000000" class="icon-instagram1"><path class="color1" d="M367.44,512H144.56C65.14,512,0.52,447.38,0.52,367.96V144.04C0.52,64.62,65.14,0,144.56,0h222.88 c79.42,0,144.04,64.62,144.04,144.04v223.92C511.48,447.38,446.86,512,367.44,512z M144.56,48.66c-52.59,0-95.38,42.79-95.38,95.38 v223.92c0,52.59,42.78,95.38,95.38,95.38h222.88c52.59,0,95.38-42.78,95.38-95.38V144.04c0-52.59-42.78-95.38-95.38-95.38H144.56z M256,389.35c-73.53,0-133.35-59.82-133.35-133.35S182.47,122.65,256,122.65S389.35,182.47,389.35,256S329.53,389.35,256,389.35z M256,171.31c-46.7,0-84.69,37.99-84.69,84.69s37.99,84.69,84.69,84.69s84.69-37.99,84.69-84.69S302.7,171.31,256,171.31z M392.32,86.23c-18.48,0-33.46,14.98-33.46,33.46s14.98,33.46,33.46,33.46c18.48,0,33.46-14.98,33.46-33.46 S410.8,86.23,392.32,86.23z" /></svg>            </a>
</li>
</ul>
</nav>
<div style="padding-bottom:104%" id="map_BLOCK_O5R989T8KT_614e2180dcf18" class="block-map blk-map">
<div id="gmap_map_BLOCK_O5R989T8KT_614e2180dcf18" class="planacces-map map_BLOCK_O5R989T8KT_614e2180dcf18 blk-map__planacces"></div>
</div>
</div>
</aside>
<!-- ==================================
Footer
=================================== --><footer class="dzone-footer"><div class="grid-template">
<div class="block-linkeo clearfix blk-linkeo"><span class="logo-linkeo blk-linkeo__logo" title="linkeo"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="51" height="20" viewBox="0 0 512 200" fill="#000000" class="icon-linkeo1"><path d="M456.4 144.4c23.5 11.9 45.8-5.6 52.8-27.8 7.4-23.5-1.5-55.6-25.2-65.4 -20.1-8.3-39.5 6.4-46.2 24.7 -0.4 0.8-0.6 1.6-0.9 2.5C431.8 100.6 433.2 132.6 456.4 144.4zM459.4 84.6c2.6-9.1 8.9-14.1 18.3-11 4.1 1.4 5.7 6.4 7 10 3.2 8.7 4 17.7 1.9 26.7 -2.5 10.5-11.8 18.2-22 11.9 -4.1-2.5-5.1-9.6-6.1-13.8C456.7 100.6 457.6 92.4 459.4 84.6z" /><path d="M407 140c12.8-7.9 1.1-28.1-11.8-20.2 -10.4 6.4-29.1 8.8-34.5-5.4 -0.3-0.8-0.6-1.8-0.9-2.7 14.2-1.7 28.3-3.6 42.5-5.8 5.5-0.8 7.9-6.5 8.6-11.2 1.7-12.9-2-26.4-10.7-36.1 -13.7-15.2-40.6-10.8-54 1.8 -16.6 15.7-13.8 51-3.7 69.4C354.7 152.5 387.9 151.8 407 140zM365.5 74.5c11.9-8.1 19.3 0.2 21.5 10.2 -9.6 1.4-19.2 2.7-28.8 3.8C359.1 82.6 361.3 77.4 365.5 74.5z" /><path d="M77.1 174.1c-16.7 1.9-35 3.2-52.2 1.3 -0.4-38.3-1.1-76.7-1.6-115 -0.2-15-23.5-15.1-23.3 0 0.6 41.7 1.4 83.4 1.7 125 0 4.8 3.5 10.3 8.6 11.2 21.7 4 45 3.1 66.8 0.7C91.9 195.8 92.1 172.5 77.1 174.1z" /><path d="M54.7 60.5c0.9 25.5 0.8 51 0.5 76.5 -0.2 15.1 23.1 15 23.3 0 0.3-25.5 0.4-51-0.5-76.5C77.5 45.5 54.2 45.4 54.7 60.5z" /><path d="M178.3 60.6c0.5 27.5 0.6 55 0.4 82.4 -16.9-28-35.3-55.4-47.3-85.7 -4.5-11.5-23.3-11-22.9 3.1 1.2 42.4 0.6 84.9 2.4 127.3 0.7 15 24 15.1 23.3 0 -1.1-25.5-1.3-50.9-1.6-76.4 15.8 27.2 33.5 53.5 46.9 81.9 5.2 11 21.5 5 21.8-5.9 1-42.3 1-84.5 0.3-126.8C201.4 45.6 178 45.5 178.3 60.6z" /><path d="M284.2 108.4c11.3-13.8 22.3-27.9 32.8-42.3 8.9-12.2-11.4-23.8-20.2-11.8 -13.8 18.9-28.6 37.3-43.8 55.2 -0.6-16.3-1.2-32.7-1.8-49 -0.5-15-23.9-15.1-23.3 0 1.6 42.3 3.4 84.8 3.5 127.1 0 15.1 23.4 15.1 23.3 0 0-14.5-0.3-29-0.7-43.5 4.7-5.5 9.5-11 14.2-16.5 12.1 21.6 23.7 43.6 35.2 65.6 7 13.3 27.1 1.5 20.2-11.8C310.7 156.9 297.9 132.4 284.2 108.4z" /><path d="M65.6 23.7c15.1 0 15.1-23.3 0-23.3C50.5 0.4 50.5 23.7 65.6 23.7z" /><path d="M497.4 169.7c-43.1 9.1-93.2 8.6-136.6 1 -14.7-2.6-21 19.9-6.2 22.5 47.7 8.4 101.5 9.1 149-0.9C518.3 189.1 512.1 166.6 497.4 169.7z" /></svg></span></div>
</div>
<div class="scrollUp">
<span class="ico"><svg width="16" height="16" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" class="icon-arrowTop4"><polygon class="color1" points="0,375.7 16.6,392.3 256,152.9 495.4,392.3 512,375.7 256,119.7 " /></svg>
</span>
</div>
</footer>
<!-- ==================================
Hero Container
=================================== --><section class="dzone-herocontainer hero-container">
<div class="block-slider">
<div class="owl-carousel header">
<div class="item-wrapper">
	<div class="item-image">
		<div class="image owl-lazy" data-src="/ressources/images/8c02ec846d67.png" data-title="" data-description="" ></div>
	</div>
</div>
</div>
</div>
</section>
<!-- ==================================
Mobile Tab-bar
=================================== --><nav id="tab-mobile" class="tab-bar fixed dzone-tabmobile">
<div class="center-small full-width">
<figure class="block-logo">
<a href="/">
<span class="logo"><img itemprop="logo" alt="The Mills BBQ" src="ressources/images/740341b4ebff.png" /></span>
<span class="name" itemprop="name">The Mills BBQ</span>
</a>
</figure>
</div>
</nav>
</div>
<!-- ==================================
Mobile Navigation
=================================== -->
<div class="dzone-mobilenav">
<div id="tab-mobile-bottom" class="fixed tab-mobile-bottom">
<nav class="tab-bar">
<div class="block-button tiny text-center vertical tab-mobile-bottom-toggle">
<a class="button">
<span class="ico"><svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" class="icon-menu2"><path class="color1" d="M15.4,1.8v1.2H0.6V1.8C0.6,1.8,15.4,1.8,15.4,1.8z M0.6,14.2h8.7v-1.2H0.6V14.2z M0.6,8.6h14.8V7.4H0.6V8.6z" /></svg></span>
<span class="txt"><span>Menu</span></span>
</a>
</div>
<div class="block-button tiny text-center vertical">
<a href="https://www.google.com/maps/place/104+Tremaine+Rd,+L9T+2W9+Milton/" target="_blank" class="button">
<span class="ico"><svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" class="icon-location6"><path class="color1" d="M254.8 229.6" /><path class="color1" d="M254.8 229.6" /><path class="color1" d="M8,16c-1.91,0-6.08-5.59-6.08-9.79C1.92,2.78,4.65,0,8,0s6.08,2.78,6.08,6.21C14.08,10.41,9.91,16,8,16z M8,1.25 c-2.66,0-4.83,2.23-4.83,4.95c0,3.78,3.88,8.5,4.83,8.54c0.95-0.04,4.83-4.76,4.83-8.54C12.83,3.48,10.66,1.25,8,1.25z M8.32,6.66 c0.1-0.04,0.19-0.1,0.26-0.18C8.75,6.33,8.83,6.12,8.83,5.9c0-0.22-0.08-0.43-0.25-0.6c-0.31-0.31-0.86-0.31-1.17,0 C7.25,5.47,7.17,5.68,7.17,5.9c0,0.22,0.08,0.43,0.25,0.58C7.57,6.64,7.78,6.73,8,6.73C8.11,6.73,8.22,6.71,8.32,6.66z" /></svg></span>
<span class="txt"><span>Map</span></span>
</a>
</div>
<div class="block-button button-style2">
<a href="https://deliver.biz/carte/carte?key=a9d7853e58c8738e31047dac36dd0699db839448&c=AGCCND6317&ui=light&lang=en&noiframe=true" target="_blank" class="button">
<span class="txt"><span>Order Now</span></span>
</a>
</div>
</nav>
<div class="tab-mobile-bottom-scroll-zone">
<nav class="bottom-bar-section">
<ul>
              <li><a href="/" target="_self">Home</a></li>
              <li><a href="/specials.php" target="_self">Specials</a></li>
              <li><a href="/menu.php" target="_self">Menu</a></li>
              <li><a href="https://deliver.biz/carte/carte?key=a9d7853e58c8738e31047dac36dd0699db839448&amp;c=AGCCND6317&amp;ui=light&amp;lang=en&amp;noiframe=true" target="_blank">Order Now</a></li>
              <li><a href="/contact.php" target="_self">Contact Us</a></li>
              <li><a href="/terms-conditions.php" target="_self">Terms and Conditions</a></li>
              <li><a href="/site-map.php" target="_self">Site Map</a></li>
</ul>
</nav>
<div class="block-contact">
<p itemprop="name" class="contact-name">
The Mills BBQ
</p>
<div itemscope="" itemtype="http://schema.org/PostalAddress" itemprop="address" class="contact-address">
<p itemprop="streetAddress">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="16" height="16" viewBox="0 0 512 512" fill="#000000" class="icon-location2"><path class="color1" d="M256,0c-77.9,0-141.1,63.2-141.1,141.1c0,77.9,61.7,168.5,141.1,304.3C335.3,309.5,397.1,219,397.1,141.1 C397.1,63.2,333.9,0,256,0z M256,188.2c-27.9,0-50.6-22.7-50.6-50.6c0-27.9,22.7-50.6,50.6-50.6c27.9,0,50.6,22.7,50.6,50.6 C306.6,165.6,283.9,188.2,256,188.2z M410.4,437.8c0,13.3-6.7,38.3-51.4,56.6c-57.5,23.5-148.4,23.5-206,0 c-44.8-18.3-51.4-43.3-51.4-56.6c0-33.5,36.9-53.1,69.1-62.7c6.2,10.6,12.7,21.4,19.3,32.6c0.2,0.3,0.4,0.6,0.6,1 c-108.6,26.9-20.5,65.6,65.5,65.6c85.8,0,173.9-38.8,65.5-65.6c0.2-0.3,0.4-0.6,0.6-1c6.6-11.2,13.1-22,19.3-32.6 C373.5,384.7,410.4,404.4,410.4,437.8z" /></svg>104 Tremaine Rd</p>
<p>
<span itemprop="addressLocality">Milton, ON</span>
<span itemprop="postalCode">L9T 2W9</span>
</p>
<p><strong>(Pick-up only)</strong></p>
<p itemprop="addressCountry" class="hide">
Canada
</p>
</div>
<p class="contact-telephone">
</p>
<br />
<p><strong>Delivery anywhere in the GTA area (Delivery charge will be subjected to distance)</strong></p>
</div>
<nav class="block-socialbar tiny style-rounded color-default">
<ul>
<li class="facebook">
<a itemprop="sameAs" rel="noreferrer" href="https://www.facebook.com/themillsbbq/photos/?ref=page_internal" title="facebook" target="_blank">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="16" height="16" viewBox="0 0 512 512" fill="#000000" class="icon-facebook1"><path class="color1" d="M293.5 494h-89.2V256h-59.5v-82l59.5 0 -0.1-48.3c0-66.9 18.1-107.6 97-107.6h65.6v82h-41c-30.7 0-32.2 11.5-32.2 32.9l-0.1 41.1h73.8l-8.7 82 -65 0L293.5 494z" /></svg>            </a>
</li>
<li class="instagram">
<a itemprop="sameAs" rel="noreferrer" href="https://www.instagram.com/themillsbbq/?hl=en" title="instagram" target="_blank">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="16" height="16" viewBox="0 0 512 512" fill="#000000" class="icon-instagram1"><path class="color1" d="M367.44,512H144.56C65.14,512,0.52,447.38,0.52,367.96V144.04C0.52,64.62,65.14,0,144.56,0h222.88 c79.42,0,144.04,64.62,144.04,144.04v223.92C511.48,447.38,446.86,512,367.44,512z M144.56,48.66c-52.59,0-95.38,42.79-95.38,95.38 v223.92c0,52.59,42.78,95.38,95.38,95.38h222.88c52.59,0,95.38-42.78,95.38-95.38V144.04c0-52.59-42.78-95.38-95.38-95.38H144.56z M256,389.35c-73.53,0-133.35-59.82-133.35-133.35S182.47,122.65,256,122.65S389.35,182.47,389.35,256S329.53,389.35,256,389.35z M256,171.31c-46.7,0-84.69,37.99-84.69,84.69s37.99,84.69,84.69,84.69s84.69-37.99,84.69-84.69S302.7,171.31,256,171.31z M392.32,86.23c-18.48,0-33.46,14.98-33.46,33.46s14.98,33.46,33.46,33.46c18.48,0,33.46-14.98,33.46-33.46 S410.8,86.23,392.32,86.23z" /></svg>            </a>
</li>
</ul>
</nav>
</div>
<div class="tab-mobile-bottom-toggle close-trigger">
<span class="ico"><svg width="16" height="16" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" class="icon-plus1"><path class="color1" d="M386,234.5H277.5V126c0-11.9-9.6-21.5-21.5-21.5s-21.5,9.6-21.5,21.5v108.5H126c-11.9,0-21.5,9.6-21.5,21.5 s9.6,21.5,21.5,21.5h108.5V386c0,11.9,9.6,21.5,21.5,21.5s21.5-9.6,21.5-21.5V277.5H386c11.9,0,21.5-9.6,21.5-21.5 S397.9,234.5,386,234.5z" /></svg></span>
</div>
</div>
</div>
<div id="tinyModal" class="reveal-modal tiny" data-reveal></div>
<div id="smallModal" class="reveal-modal small" data-reveal></div>
<div id="mediumModal" class="reveal-modal medium" data-reveal></div>
<div id="largeModal" class="reveal-modal large" data-reveal></div>
<div id="xlargeModal" class="reveal-modal xlarge" data-reveal></div>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyACfYfCcJn5WlETkaTDI1QFd5OkVjvJxsQ"></script>
<script src="/AMBIANCE_FBNWQMW54V_bambooBay-grid/js/build/ideo3.min.js"></script>
<script src="/AMBIANCE_FBNWQMW54V_bambooBay-grid/template/slider/header/owl.option.header.js"></script>
<script src="/AMBIANCE_FBNWQMW54V_bambooBay-grid/template/js/template.min.js"></script>
<script src="/js/PAGE_3V7GW8COY5.min.js?v=1632510337"></script><script>Epeius.addTracker( { name: 'Google Analytics', id: 'ga', cookies: ['_ga', '_gat', '_gid'], config: {key: 'UA-198112569-36'} } );</script><script>Epeius.addTracker( { name: 'Google Ads Remarketing', id: 'gawr', config: {key: '985359031', params: {cbtn: 'ba2552892889e25acf587c1b74004b2e2f5aca9a', dpt: 'L9T 2W9', region: 'ON', pays:'CA', cat: 'loisir-tourisme', souscat: 'restaurants'}} } );</script></body></html>